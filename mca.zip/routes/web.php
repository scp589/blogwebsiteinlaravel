<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\allkhabarc;
use App\Http\Controllers\Form;
use App\Http\Controllers\SingupForm;
use App\Http\Controllers\Wallet;
use App\Http\Controllers\PaymentsRequestAndHistory;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',  [allkhabarc::class, 'data_for_allkhabar']);

Route::get('/single_cat/{cat}', [allkhabarc::class, 'singlecat']);

Route::get('/single_blog/{blog}', [allkhabarc::class, 'singleblog']);

Route::get('/about', function (){
    return view('about');
});
Route::get('/team', function (){
    return view('teamslider');
});

Route::get('/contact', function(){
    return view('contact');
});
Route::get('/termandcondition', function(){
    return view('termsandconditions');
});

Route::post('/searchr', [allkhabarc::class, 'search']);

Route::post('/more_news', [allkhabarc::class, 'morenews']);

Route::post('/mslider', [allkhabarc::class, 'mslider']);

//middleware section start

Route::group(['middleware' => ['UserAuthcate']], function (){
 Route::post('/login_valid', [Form::class, 'login_verify']);

 
 Route::post('/update_total_amount', [Form::class, 'update_amount']);
 Route::post('/get_wallet_balance', [Form::class, 'get_amount']);
 Route::get('/wallet', [Wallet::class, 'wallet_check']);
 Route::get('/verify', [Wallet::class, 'verify_email']);
 Route::post('/otpcheck', [Wallet::class, 'otp_check']);
 Route::post('/paymentrequest', [PaymentsRequestAndHistory::class, 'payment_request_submit']);
 Route::get('/paymenthistory', [PaymentsRequestAndHistory::class, 'payment_history']);
});
//middleware section end
Route::get('/loggedout', [Form::class, 'logout']);

Route::get('/singup', function (){
    return view('singup');
});

Route::post('/sing_up', [SingupForm::class, 'sing_up']);