
<?php $__env->startSection('mainbody'); ?>
<div class="container-fluid mt-5">
    <h3 class="mb-3">Privacy Policy</h3>
    <section class="general-section">
        <h4>General</h4>
        <p class="para-for-privacy">
        These Terms and Conditions, (privacy policy) conduct your access to and use of this website/(s) (“website” or “site”) operated by mcanewswala.com.This statement mentions the privacy practices for the websites of do not have any registered office.
        </p>
    </section>
    <section class="publish-news-section">
        <h4>About Publish news</h4>
        <p class="para-for-privacy">
        News that we provide is based on a real source and data, content of social media but we do not claim that this information is completely correct.
        </p>
    </section>
    <section class="sources-section">
        <h4>Information from other Sources</h4>
        <p class="para-for-privacy">
        We might get data about you from different sources, add it to our record data and treat it as per our terms and conditions. Assuming you give data to the stage supplier or other accomplice, whom we offer types of assistance, your record data and request data might be given to us. We might get refreshed contact data from third parties for our records and fulfill the Services or to communicate with you. Data on your interest outside the ANN when you talk about us like if you've tagged us in a Twitter post, we'll gather your Twitter handle.
        </p>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/termsandconditions.blade.php ENDPATH**/ ?>