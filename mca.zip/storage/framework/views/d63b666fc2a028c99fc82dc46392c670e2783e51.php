<div>
<div class="container-fluid mt-3">
    <div class="row">
        <div class="col-sm-3 col-md-2 col-lg-2">
            <h6 class="text-center breaking-mrq-heading p-2">Top Articals</h6>
        </div>
        <div class="col-sm-9 col-md-10 col-lg-10">
            <marquee behavior="" direction="" onmouseover="this.stop();" onmouseout="start()">
                <div>
                    <ul class="marq-ul marq-container" id="mslider">
                    <input type="hidden" name="_token" id="token1" value="<?php echo e(csrf_token()); ?>">
                       
                    </ul>
                </div>
            </marquee>
        </div>
    </div>
</div>
</div><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/components/slider.blade.php ENDPATH**/ ?>