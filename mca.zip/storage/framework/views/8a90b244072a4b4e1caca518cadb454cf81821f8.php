
<?php $__env->startSection('mainbody'); ?>
<div class="container">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Amount</th>
            <th scope="col">Acoount Number</th>
            <th scope="col">Transaction Type</th>
            <th scope="col">Transaction Date</th>
            <th scope="col">Transaction Status</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $dataforpayhistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_forpay_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
             $st ="";  
             if($row_forpay_history['transiction_status'] == 'pending'){
                 $st = 'warning';
             }
             elseif ($row_forpay_history['transiction_status'] == 'payed') {
                 $st = 'success';
             }
             elseif($row_forpay_history['transiction_status'] == 'failed'){
                 $st = 'danger';
             }
             else {
                 $st = "";
             }
            ?>
          
          <tr class="table-<?php echo e($st); ?>">
            <td><?php echo e($row_forpay_history['amount']); ?></td>
            <td><?php echo e($row_forpay_history['account_number']); ?></td>
            <td><?php echo e($row_forpay_history['account_number']); ?></td>
            <td><?php echo e($row_forpay_history['transiction_type']); ?></td>
            <td><?php echo e($row_forpay_history['transiction_date']); ?></td>
            <td><?php echo e($row_forpay_history['transiction_status']); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/paymenthistory.blade.php ENDPATH**/ ?>