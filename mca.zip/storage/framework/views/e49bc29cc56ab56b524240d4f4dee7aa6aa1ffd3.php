<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="<?php echo e(asset('asset/js/fontawosome.js')); ?>"></script>
    <link href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/main.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mukta:wght@300&family=Roboto:wght@300&display=swap"
        rel="stylesheet">
        <link rel="shortcut icon" href="<?php echo e(asset('asset/images/logo5.png')); ?>" type="image/x-icon">
    <title id="title"><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>  
  <!-- Modal start -->
  <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Login</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
         <p>Your earning is stopped please login to start earning. if you don't have account yet please sinup first then login.</p>
         <form action="/login_valid" method="POST">
             <?php echo e(@csrf_field()); ?>

            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Email address/User name</label>
              <input type="text" minlength="7" class="form-control" id="user-email" name="user-email" aria-describedby="emailHelp" required>
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input type="password" minlength="8" class="form-control" id="pass" name="pass" required>
            </div>
        </div>
        <div class="modal-footer">
            <a href="/singup" class="btn btn-primary">Singup</a>
            <button type="submit" class="btn btn-success">Login</button>
        </form>
        </div>
      </div>
    </div>
  </div>
  
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
    <div class="mainbody">
    <?php $__env->startSection('mainbody'); ?>

    <?php echo $__env->yieldSection(); ?>
</div>
<!-- <img src="<?php echo e(asset('asset/images/animation/5061-happy-holi-animation.gif')); ?>" class="festival" alt="" style="height: 100px;"> -->
    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
    <script src="<?php echo e(asset('asset/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/owl.carousel.min.js')); ?>"></script>
    <script>
        var myModal = new bootstrap.Modal(document.getElementById('myModal'), {
    keyboard: false
  });
   

   var session_loggedin = '<?php echo e(session('loggedin')); ?>';
   if(session_loggedin==true){
       var token = '<?php echo e(csrf_token()); ?>';
      //  var increase_amount = 0.1;
       var session_user_name = '<?php echo e(session('username')); ?>';

       //getting data once start
       $.post('/get_wallet_balance', {
           sessname : session_user_name,
           _token : token
       }, function (data, status){
           console.log(`ststus for gewallet balance ${status}`);
           console.log(data);
           var wallet_btn = document.getElementsByClassName('wallet');
           Array.from(wallet_btn).forEach(element => {
               element.innerText = data;
           });
       });
//getting data once end
      // update data start
      //  setInterval(() => {
      //   var wallet_btn1 = document.getElementsByClassName('wallet')[0];
      //   var stonum = Number(wallet_btn1.innerText);
      //  var finalamount = stonum+increase_amount;
      //  var oneafdecimal = finalamount.toFixed(1);
      //  console.log(oneafdecimal);
      //  console.log('finalamount '+ finalamount)
      //    $.post('/update_total_amount', {
      //       sessionname : session_user_name,
      //       amount : oneafdecimal,
      //       _token : token
      //    }, function (data, status){
      //         console.log(`ststus for update ${status}`);
      //    }); 
      //  }, 30000);
       //update data end
       
//getting data after 31 sec start
       setTimeout(() => {
        $.post('/get_wallet_balance', {
           sessname : session_user_name,
           _token : token
       }, function (data, status){
           console.log(`ststus for gewallet balance ${status}`);
           console.log(data);
           var wallet_btn = document.getElementsByClassName('wallet');
           Array.from(wallet_btn).forEach(element => {
               element.innerText = data;
           });
       });
       }, 31000);
       //getting data after 31 sec start
       console.log(`this is sessionloggedin ${session_loggedin}`);
   }
   else{
       console.log('loogedoout');
      //  setTimeout(() => {
      //    myModal.toggle()
      //  }, 8000);
       var wallet_btn2 = document.getElementsByClassName('wallet');
       Array.from(wallet_btn2).forEach((element)=>{
           element.innerText = 0;
       });
   }

   function open_modal(){
     myModal.toggle();
   }

    </script>
</body>
</html><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/main.blade.php ENDPATH**/ ?>