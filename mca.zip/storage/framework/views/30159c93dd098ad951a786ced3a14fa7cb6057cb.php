
<?php $__env->startSection('mainbody'); ?>
<div class="container mt-3">
<form action="/sing_up" method="POST">
  <?php echo e(@csrf_field()); ?>

    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">User name</label>
      <input type="text" minlength="7" class="form-control" id="user-name-singup" name="user-name-singup" aria-describedby="emailHelp" required>
    </div>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Email address</label>
      <input type="email" minlength="7" class="form-control" id="email-singup" name="email-singup" aria-describedby="emailHelp" required>
      <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Password</label>
      <input type="password" minlength="8" class="form-control" id="pass-singup" name="pass-singup" required>
      <div id="emailHelp" class="form-text">Your password and confirm password must be same.</div>
    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Confirm password</label>
      <input type="password" class="form-control" id="conpass-singup" name="conpass-singup" required>
      <div id="emailHelp" class="form-text">Your password and confirm password must be same.</div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/singup.blade.php ENDPATH**/ ?>