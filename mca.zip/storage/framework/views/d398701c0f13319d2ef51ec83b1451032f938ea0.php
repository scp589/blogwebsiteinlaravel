<h4>request amount <?php echo e($aboutpayreqadmin['reqamount']); ?></h4>
<h4>request number <?php echo e($aboutpayreqadmin['reqnum']); ?></h4>
<h4>request number <?php echo e($aboutpayreqadmin['paytype']); ?></h4>
<h4>user name <?php echo e($name); ?></h4>
<h4>user email <?php echo e($mid); ?></h4><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/payrequestmailadmin.blade.php ENDPATH**/ ?>