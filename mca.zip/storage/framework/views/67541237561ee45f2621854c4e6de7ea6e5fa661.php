
<?php $__env->startSection('title', 'MCAnewsWALA'); ?>
<?php $__env->startSection('mainbody'); ?>
<!-- slider component start -->
<?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slider::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>
<!-- slider component end -->
    <!-- badikhabar section start -->
    <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>बड़ी ख़बरें</h3><a href="/single_cat/badikhabar">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($dataforbadikhabar)>0){
            foreach ($dataforbadikhabar as $row_for_badikhabar) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_badikhabar['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_badikhabar['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_badikhabar['seo_url_heading'].'">'.$row_for_badikhabar['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- badikhabar section end -->

    <!-- desh section start -->
    <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>देश</h3><a href="/single_cat/country">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($datafordeshkikhabar)>0){
            foreach ($datafordeshkikhabar as $row_for_desh_ki_khabar) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_desh_ki_khabar['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_desh_ki_khabar['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_desh_ki_khabar['seo_url_heading'].'">'.$row_for_desh_ki_khabar['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- desh section end -->
    <!-- state section start -->
    <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>राज्य</h3><a href="/single_cat/state">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($dataforstate)>0){
            foreach ($dataforstate as $row_for_state) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_state['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_state['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_state['seo_url_heading'].'">'.$row_for_state['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- state section end -->
    <!-- district section start -->
    <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>जिला</h3><a href="/single_cat/district">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($datafordistrict)>0){
            foreach ($datafordistrict as $row_for_district) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_district['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_district['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_district['seo_url_heading'].'">'.$row_for_district['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- district section end -->
    <!-- tech section start -->
    <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>तक्नीकी</h3><a href="/single_cat/tech">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($datafortech)>0){
            foreach ($datafortech as $row_for_tech) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_tech['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_tech['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_tech['seo_url_heading'].'">'.$row_for_tech['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- tech section end -->
    <!-- job section start -->
    <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>नौकरी</h3><a href="/single_cat/job">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($dataforjob)>0){
            foreach ($dataforjob as $row_for_job) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_job['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_job['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_job['seo_url_heading'].'">'.$row_for_job['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- job section end -->

    <!-- video section start -->
    <section class="video-section mt-3 container-fluid bg-dark pt-2">
        <div class="video-heading">
            <h3>वीडियो</h3><a href="#youtube channel link">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6">
                <?php
                if(count($dataformainvideo)>0){
                    foreach ($dataformainvideo as $row_for_main_video) {
                        echo '<iframe width="100%" height="315" src="'.$row_for_main_video['video_src'].'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <a href="?page=single_blog&videonum='.$row_for_main_video['main_heading'].'" class="video-link">
                <p>'.$row_for_main_video['main_heading'].'</p>
            </a>';
                    }
                }
                else{
                    echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
                }
                ?>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="row">
                    <?php
                    if(count($dataforside4video)>0){
                        foreach ($dataforside4video as $row_for_side4_video) {
                            echo '<div class="col-lg-6">
                            <iframe width="100%" height="200" src="'.$row_for_side4_video['video_src'].'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <a href="?page=single_blog&videonum='.$row_for_side4_video['main_heading'].'" class="video-link">
                            <p>'.$row_for_side4_video['main_heading'].'</p>
                        </a>
                        </div>';
                        }
                    }
                    else{
                        echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
                    }
                        ?>
                </div>
            </div>
        </div>
    </section>
    <!-- video section end -->

     <!-- job section start -->
     <section class="container-fluid badikhabar-section">
        <div class="badikhabar-heading">
            <h3>खेल</h3><a href="/single_cat/game">और ख़बरें <i class="fas fa-caret-right"></i></a>
        </div>
        <div class="row badikhabar-new-container">
            <?php
           if(count($dataforgame)>0){
            foreach ($dataforgame as $row_for_game) {
                echo ' <div class="one-news col-sm-12 col-md-12 col-lg-6">
                <img class="one-news-img" src="asset/images/'.$row_for_game['image_name'].'" alt="image load failed">
                <div class="one-news-para-container">
                    <p><span class="for-hlc">'.$row_for_game['rajay_name'].' </span><span class="slash">/</span> <a href="/single_blog/'.$row_for_game['seo_url_heading'].'">'.$row_for_game['main_heading'].'</a></p>
                </div>
            </div>';
            }
           } 
           else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
           }
            ?>
        </div>
    </section>
    <!-- job section end -->
<script>
    var session_loggedin = '<?php echo e(session('loggedin')); ?>';
   if(session_loggedin==true){
       var token = '<?php echo e(csrf_token()); ?>';
       var increase_amount = 0.1;
       var session_user_name = '<?php echo e(session('username')); ?>';
      // update data start
       setTimeout(() => {
        var wallet_btn1 = document.getElementsByClassName('wallet')[0];
        var stonum = Number(wallet_btn1.innerText);
       var finalamount = stonum+increase_amount;
       var oneafdecimal = finalamount.toFixed(1);
       console.log(oneafdecimal);
       console.log('finalamount '+ finalamount)
         $.post('/update_total_amount', {
            sessionname : session_user_name,
            amount : oneafdecimal,
            _token : token
         }, function (data, status){
              console.log(`ststus for update ${status}`);
         }); 
       }, 30000);
       //update data end
       
       console.log(`this is sessionloggedin ${session_loggedin}`);
   }
   else{
       console.log('loogedoout');
       setTimeout(() => {
         myModal.toggle()
       }, 8000);
       var wallet_btn2 = document.getElementsByClassName('wallet');
       Array.from(wallet_btn2).forEach((element)=>{
           element.innerText = 0;
       });
   }
</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/allkhabar.blade.php ENDPATH**/ ?>