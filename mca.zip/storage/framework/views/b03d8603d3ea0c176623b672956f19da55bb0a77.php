
<?php $__env->startSection('mainbody'); ?>
<div class="alert alert-success d-flex align-items-center" role="alert">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-exclamation-triangle-fill flex-shrink-0 me-2" viewBox="0 0 16 16" role="img" aria-label="Warning:">
        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
    </svg>
    <div>
      otp has been sent on <?php echo e($dataforotpmessage[0]->email_address); ?> email address
    </div>
  </div>
<div class="container">
    <form action="/otpcheck" method="POST">
      <?php echo e(@csrf_field()); ?>

        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Enter 6 digits otp</label>
          <input type="number" class="form-control" id="otp" name="otp" aria-describedby="emailHelp" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/verify.blade.php ENDPATH**/ ?>