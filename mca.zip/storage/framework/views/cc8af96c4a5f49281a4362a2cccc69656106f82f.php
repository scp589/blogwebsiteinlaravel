
<?php $__env->startSection('mainbody'); ?>
    <!-- single blog start -->
<div class="container pt-2 mt-2">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-8">
                <!-- geeting current url start -->
                <?php 
                $getting_current_url = urlencode("https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]")
                ?>
                <!-- geeting current url end -->
                <?php $__currentLoopData = $dataforsingleblog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_for_single_blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->startSection('title', $row_for_single_blog['main_heading']); ?>
                <h3 class="news-heading mt-2"><?php echo e($row_for_single_blog['main_heading']); ?></h3>
                     <h6 class="pt-2 news-min-discription"><?php echo e($row_for_single_blog['min_discription']); ?></h6>
                     <p class="mt-2">By MCAnewsWALA Digital Desk | Updated Date <?php echo e($row_for_single_blog['updated_date']); ?></p>
                     <div class="share-links">
                         <span class="share-p">share-on:- </span>
                         <a target="_blank" href="https://wa.me/?text=<?php echo e($getting_current_url); ?> | <?php echo e($row_for_single_blog['main_heading']); ?>"><i class="fab fa-whatsapp whatsapp-icon 
                            icon-size-share"></i></a>
                         <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($getting_current_url); ?>&quote=<?php echo e($row_for_single_blog['main_heading']); ?>"><i class="fab fa-facebook-f icon-size-share"></i></a>
                         <a target="_blank" href=" https://twitter.com/intent/tweet?via=<?php echo e($getting_current_url); ?>&text=<?php echo e($row_for_single_blog['main_heading']); ?>"><i class="fab fa-twitter twitter-icon icon-size-share"></i></a>
                     </div>
                     <img class="single-main-image" src="../asset/images/<?php echo e($row_for_single_blog['image_name']); ?>" alt="image load failed">
                     <p class="ssingle-snews-spara mt-5"><span class="for-city"><?php echo e($row_for_single_blog['place_name']); ?>:- </span><?php echo $row_for_single_blog['full_news']; ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>

            <div class="col-sm-12 col-md-12 col-lg-4">
                <h4 class="another-news">अन्य खबरें</h4>
                <div class="div-like-hr"></div>
                <div class="row mt-3">
                    <?php
                    if(count($dataforanothernews)>0){
                        foreach ($dataforanothernews as $row_for_another_news) {
                            echo '<div class="mt-2 col-sm-12 col-md-12 col-lg-12">
                            <a href="/single_blog/'.$row_for_another_news['seo_url_heading'].'" class="another-news-link">
                                <img class="another-image" src="../asset/images/'.$row_for_another_news['image_name'].'"
                                    alt="image-load-failed">
                                <p class="another-min-heading">'.$row_for_another_news['main_heading'].'</p>
                            </a>
                        </div>';
                        }
                    }
                    else{
                        echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
<!-- single blog end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/singleblog.blade.php ENDPATH**/ ?>