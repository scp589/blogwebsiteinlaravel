<div>
<header class="top-header">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                    <!-- <a class="navbar-brand" href="/"><img src="<?php echo e(asset('asset/images/logo5.png')); ?>" alt=""></a> -->
                    <form method="post" action="/searchr" class="d-flex">
                    <?php echo e(@csrf_field()); ?>

                        <input required class="form-control me-2" type="search" name="search-word" placeholder="Search" aria-label="Search" />
                        <button class="btn btn-outline-success" type="submit">
                            Search
                        </button>
                    </form>
                <div class="navbar-toggler snavbar-toggler">
                   <!-- empty -->
                    <div>
                    <a href="/wallet" class="btn btn-danger subscribe-btn mt-2 wallet"></a>
                    </div>
                </div>
                <div class="collapse navbar-collapse" id="">
                    <div class="navbar-nav m-auto mb-2 mb-lg-0">
                        <span class="folow">Follow us on:- </span>
                        <a target="_blank" href="https://www.facebook.com/MCA-news-WALA-107496331840938/"><i class="fab fa-facebook-f"></i></a><span class="hr"></span>
                        <a target="_blank" href="https://www.youtube.com/channel/UC42NWoRDKK13i6hpNHpajiA"><i class="fab fa-youtube youtube-icon"></i></a><span class="hr"></span>
                        <a target="_blank" href=""><i class="fab fa-twitter twitter-icon"></i></a><span class="hr"></span>
                        <a target="_blank" href="https://www.instagram.com/mcanewswala/"><i class="fab fa-instagram instagram-icon"></i></a><span class="hr"></span>
                    </div>
                    <div>
                    <a href="/wallet" class="btn btn-danger subscribe-btn mt-2 wallet"></a>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- top header end -->

    <!-- navbar start -->
    <nav class="navbar navbar1 navbar-expand-lg navbar-light for-sticky">
        <div class="container-fluid">
        <a class="navbar-brand" href="/"><img src="<?php echo e(asset('asset/images/whitelogo5.png')); ?>" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/">होम</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/single_cat/badikhabar">बड़ी ख़बरें</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/single_cat/country">देश</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            राज्य
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="/single_cat/state">राज्य</a></li>
                            <li><a class="dropdown-item" href="/single_cat/utterpardesh">उत्तर-प्रदेश</a></li>
                            <li><a class="dropdown-item" href="/single_cat/madhaypardesh">मध्य-प्रदेश</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            जिला
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item " href="/single_cat/district">जिला</a></li>
                            <li><a class="dropdown-item " href="/single_cat/aligarh">अलीगढ़</a></li>
                            <li><a class="dropdown-item" href="/single_cat/kanpur">कानपुर</a></li>
                            <li><a class="dropdown-item" href="/single_cat/noida">नोएडा</a></li>
                            <li><a class="dropdown-item" href="/single_cat/hathrash">हाथरस</a></li>
                            <li><a class="dropdown-item" href="/single_cat/sikandrarao">सिकन्द्राराओ</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="/single_cat/tech" class="nav-link">तक्नीकी</a>
                    </li>
                    <li class="nav-item">
                        <a href="/single_cat/job" class="nav-link">नौकरी</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            खेल
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item " href="/single_cat/game">सभी खेल</a></li>
                            <li><a class="dropdown-item " href="/single_cat/circket">क्रिकेट</a></li>
                            <li><a class="dropdown-item" href="anothergame">अन्य खेल</a></li>
                        </ul>
                    </li>
                    <?php
                    $d_none = "";
                    if (session()->has('username')) {
                        $d_none = 'd-none';
                    }
                    else {
                        $d_none = "";
                    }
                    ?>    
                    
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($d_none); ?>" onclick="open_modal()">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($d_none); ?>" href="/singup">Singup</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/loggedout">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<?php
$s = session('username');
?>
<?php echo session('logginerror'); ?>


<?php if(session()->has('username')): ?>
<?php echo '<div class="alert alert-success d-flex align-items-center" role="alert">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-exclamation-triangle-fill flex-shrink-0 me-2" viewBox="0 0 16 16" role="img" aria-label="Warning:">
        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
    </svg>
    <div>
      Welcome '.session('username').' you are logged in successfuly. enjoy earning.
    </div>
  </div>'; ?>

<?php endif; ?>
<?php echo session('loggedoutsuccess'); ?>

<?php echo session('usernameandemailexits'); ?>

<?php echo session('usernameexits'); ?>

<?php echo session('emailexits'); ?>

<?php echo session('accoountcreated'); ?>

<?php echo session('passwordnotmatch'); ?>

<?php echo session('accessdinid'); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/components/navbar.blade.php ENDPATH**/ ?>