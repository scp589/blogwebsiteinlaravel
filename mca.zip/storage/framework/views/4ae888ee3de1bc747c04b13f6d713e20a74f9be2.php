<h4><?php echo e($aboutpayreq); ?></h4>

<h5><?php echo e($care); ?></h5><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/payrequestmail.blade.php ENDPATH**/ ?>