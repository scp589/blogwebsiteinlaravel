
<?php $__env->startSection('mainbody'); ?>
<!-- slider start -->
<?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Slider::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>
<!-- slider end -->
 <!-- singlecat start -->
 <section class="container-fluid badikhabar-section">
     <div class="badikhabar-heading">
         <h3><?php
         $dynemaic_heading = "";
         if($mainheading == 'badikhabar'){
             $dynemaic_heading = 'बड़ी ख़बरें';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "country"){
             $dynemaic_heading = 'देश';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "state"){
             $dynemaic_heading = 'राज्य ';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "district"){
             $dynemaic_heading = 'जिला';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "tech"){
             $dynemaic_heading = 'तक्नीकी';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "job"){
             $dynemaic_heading = 'नौकरी';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "game"){
             $dynemaic_heading = 'नौकरी';
             echo $dynemaic_heading;
         }
         ?></h3>
     </div>
     <div class="row badikhabar-new-container" id="cmorenews">
         <input type="hidden" id="incat" value="<?php echo $mainheading;?>">
         
        <?php
        if(count($dataforsinglecat)>0){
            foreach ($dataforsinglecat as $row_for_single_cat) {
                echo '<div class="one-news col-sm-12 col-md-12 col-lg-6">
                        <img class="one-news-img" src="../asset/images/'.$row_for_single_cat['image_name'].'" alt="image load failed">
                        <div class="one-news-para-container">
                            <p><span class="for-hlc">'.$row_for_single_cat['rajay_name'].' </span><span class="slash">/</span> <a class="mainheading" href="/single_blog/'.$row_for_single_cat['seo_url_heading'].'">'.$row_for_single_cat['main_heading'].'</a></p>
                        </div>
                    </div>';
            }
        }
        else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
        }
        ?>
     </div>
     <button class="btn aling-text-center mt-2 button-for-more-news" id="morenews">और ख़बरें</button>
 </section>
 <!-- singlecat end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\mcanewswala.comv2\resources\views/singlecat.blade.php ENDPATH**/ ?>