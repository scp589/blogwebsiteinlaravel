// multiselect logic start
check_in = document.getElementsByClassName("check-in");
Array.from(check_in).forEach((element)=>{
    element.style.display = "none";
});

function multi_select(){
    Array.from(check_in).forEach((element)=>{
        if(element.style.display == "none"){
            element.style.display = "inline-block";
        }
        else{
            element.style.display = "none";
        }
    });
}
// multiselect logic end
//reload page automaticaly logic start
setTimeout(() => {
    location.reload()
}, 1.8e+6);
//reload page automaticaly logic end

// addmoney logic start

// addmoney logic end
// more news start
let ltnum = 12;
var incat = $('#incat').val();
var token = $('#token').val()
$('#morenews').click(function() {
    // console.log("jiu")
    $.post('/more_news', {
        start_selected: ltnum,
        mcat: incat,
        _token: token
    }, function(data, status) {
        console.log(`done`);
        // console.log(data);
        console.log(ltnum);
        $('#cmorenews').append(data);
        ltnum += 6;
    });
});    

//more news end

//slider start
$(document).ready(function(){
    var token1 = $('#token1').val()
    if(token1!=null){
        $.post('/mslider', {
            scat: 'breakingnews',
            _token: token1
        }, function(data, status) {
            // console.log(status);
            console.log(`doneslider`);
            // console.log(data);
            // var html;
            data.forEach(element => {
                html = `<li class="list-item"><a href="/single_blog/${element.seo_url_heading}">${element.main_heading}</a></li>`;
                $('#mslider').append(html);
                console.log(1)
            });
        });
    }
});
   //slider end
   
// wallet form logic start
const phonepe = document.getElementById('phonepe');
const googlepay = document.getElementById('googlepay');
const bankaccount = document.getElementById('bankaccount');
let main_pay_form = document.getElementById('main-pay-form');
var phone_number_type = '';
function changedata(){
    main_form_data = `<div class="mb-3">
    <label for="inputforamount" class="form-label">Amount*</label>
    <input type="number" class="form-control" id="exampleInputEmail1" name="reqamount" aria-describedby="emailHelp" required>
    </div>
    <div class="mb-3">
    <label for="imputphonepe" class="form-label">${phone_number_type} Number*</label>
    <input type="number" class="form-control" id="exampleInputPassword1" name="reqnum" required>
    </div>
    <div class="mb-3">
    <label for="imputcomfirm" class="form-label">Confirm ${phone_number_type} Number*</label>
    <input type="number" class="form-control" id="exampleInputPassword1" name="reqcnum" required>
  </div>
    <button type="submit" class="btn btn-primary">Submit</button>`;
}

//  console.log(phone_number_type)
phonepe.addEventListener('click', ()=>{
    phone_number_type = 'Phonepe';
    changedata();
    main_pay_form.innerHTML = main_form_data;
});

googlepay.addEventListener('click', ()=>{
    phone_number_type = 'Googlepay';
    changedata();
    main_pay_form.innerHTML = main_form_data;
});

bankaccount.addEventListener('click', ()=>{
    main_pay_form.innerHTML = `<div class="mb-3">
    <label for="inputforamount" class="form-label">Amount*</label>
    <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
  </div>
  <div class="mb-3">
    <label for="imputphonepe" class="form-label">Account Number*</label>
    <input type="number" class="form-control" id="exampleInputPassword1" required>
  </div>
  <div class="mb-3">
    <label for="imputcomfirm" class="form-label">Confirm Account Number*</label>
    <input type="number" class="form-control" id="exampleInputPassword1" required>
  </div>
  <div class="mb-3">
    <label for="imputifsc" class="form-label">IFSC</label>
    <input type="text" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="mb-3">
    <label for="imputAccountholdername" class="form-label">Account holder name*</label>
    <input type="text" class="form-control" id="exampleInputPassword1" required>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>`; 
});

// this is for payment history check porpose code
const payment_history = document.getElementById('payment-history');

payment_history.addEventListener('click', ()=>{
    main_pay_form.innerHTML = `<table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col">Amount</th>
        <th scope="col">Acoount Number</th>
        <th scope="col">Transiction Type</th>
        <th scope="col">Transiction Date</th>
        <th scope="col">Transiction Status</th>
      </tr>
    </thead>
    <tbody>
      <tr class="table-danger">
        <td>Mark</td>
        <td>Otto</td>
        <td>@mdo</td>
        <td>Otto</td>
        <td>@mdo</td>
      </tr>
      <tr>
        <td>Jacob</td>
        <td>Thornton</td>
        <td>@fat</td>
        <td>Otto</td>
        <td>@mdo</td>
      </tr>
      <tr>
        <td>Larry the Bird</td>
        <td>@twitter</td>
        <td>Otto</td>
        <td>@mdo</td>
      </tr>
    </tbody>
  </table>`; 
});

// wallet form logic end
