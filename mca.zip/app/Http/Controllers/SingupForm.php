<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Sinup;

class SingupForm extends Controller
{
    function sing_up(Request $request_for_singup){
        $request_store_for_singup = $request_for_singup->post();
        $request_for_singup->validate([
            'user-name-singup' => 'required|min:7',
            'email-singup' => 'required|email|min:7',
            'pass-singup' => 'required|min:8',
        ]);
        $getting_p_url = $_SERVER['HTTP_REFERER'];
        $res_check_user_name_exits_or_not = Sinup::where('user_name', $request_store_for_singup['user-name-singup'])->get();
        $res_check_eamil_exits_or_not = Sinup::where('email_address', $request_store_for_singup['email-singup'])->get();
        if(count($res_check_user_name_exits_or_not)>0 && count($res_check_eamil_exits_or_not)>0){
            session()->flash('usernameandemailexits', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Warning!</strong> User name and email you entered is already exits.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          return redirect($getting_p_url);
        }
        elseif(count($res_check_user_name_exits_or_not)>0){
            // echo 'user name already exits';
            session()->flash('usernameexits', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Warning!</strong> User name you entered is already exits.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          return redirect($getting_p_url);
        }
        elseif(count($res_check_eamil_exits_or_not)>0){
            // echo 'email already exits';
            session()->flash('emailexits', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Warning!</strong> Email you entered is already exits.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          return redirect($getting_p_url);
        }
        else{
            if($request_store_for_singup['pass-singup'] == $request_store_for_singup['conpass-singup']){
                $res_for_insert = Sinup::create([
                    'user_name' => $request_store_for_singup['user-name-singup'],
                    'email_address' => $request_store_for_singup['email-singup'],
                    'password' => $request_store_for_singup['pass-singup'],
                    'total_amount' => 0,
                    'otp' => '1@$1^&',
                    'email_verify' => 'not verified',
                ]);
                if($res_for_insert){
                    // echo 'your acount is created';
                    session()->flash('accoountcreated', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Welcome!</strong> Your account is craeted successfully login to activet your account.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          return redirect('/');
                }
            }
            else{
                // echo 'password do not match';
                session()->flash('passwordnotmatch', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Warning!</strong> Passwords you entered do not match.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          return redirect($getting_p_url);
            }
        }
        // echo $request_for_singup;
    }
}
