<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\UserLogin;

class Form extends Controller
{
    function login_verify(Request $request_for_login){
        $request_store_for_login = $request_for_login->post();
        $request_for_login->validate([
            'user-email' => 'required|min:7',
            'pass' => 'required|min:8'
        ]);
        $res_for_login = UserLogin::where('user_name', $request_store_for_login['user-email'])->where('password', $request_store_for_login['pass'])->orWhere('email_address', $request_store_for_login['user-email'])->where('password', $request_store_for_login['pass'])->get();
        if(count($res_for_login)>0){
            // echo $request_store_for_login['user-email'];
            session()->put('loggedin', true);
            session()->put('username', $request_store_for_login['user-email']);
            $getting_privious_url = $_SERVER['HTTP_REFERER'];
        //     session()->flash('logginsuccess', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        //     <strong>Welcome '.session('username').'!</strong> You are logged in successfully.
        //     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        //   </div>');
            return redirect($getting_privious_url);
        }
        else{
            // echo 'invailid details';
            $getting_privious_url = $_SERVER['HTTP_REFERER'];
            session()->flash('logginerror', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Login warning!</strong> Invailed login details.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
            return redirect($getting_privious_url);
        }
    }

    function update_amount(Request $request_for_update_amount){
        $request_store_for_update = $request_for_update_amount->post();
        $res_for_update = UserLogin::where('user_name', $request_store_for_update['sessionname'])->orWhere('email_address', $request_store_for_update['sessionname'])->update(['total_amount' => $request_store_for_update['amount']]);
    }

    function get_amount(Request $request_for_get_amount){
        $request_store_for_get_amount = $request_for_get_amount->post();

        $res_for_get_amount = UserLogin::where('user_name', $request_store_for_get_amount['sessname'])->orWhere('email_address', $request_store_for_get_amount['sessname'])->get();
        if($res_for_get_amount){
            return $res_for_get_amount[0]->total_amount;
        }
    }

    function logout(){
        session()->forget('loggedin');
        session()->forget('username');
        session()->flash('loggedoutsuccess', '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Log out successfully!</strong> Log out successfully login again to start earning.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>');
        return redirect('/');
    }
}
