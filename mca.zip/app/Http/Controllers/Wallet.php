<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserLogin;
use Mail;

class Wallet extends Controller
{
    function wallet_check(){
        $res_for_Walletval = UserLogin::where('user_name', session('username'))->orWhere('email_address', session('username'))->get();
        return view('wallet', ['dataforwallet'=>$res_for_Walletval]);
    }

    function verify_email(){
        $res_for_otp_message = UserLogin::where('user_name', session('username'))->orWhere('email_address', session('username'))->get();
        $otp = rand(111111, 999999);
        $res_for_update_otp_in_database = UserLogin::where('user_name', session('username'))->orWhere('email_address', session('username'))->update(['otp' => $otp]);
        if($res_for_update_otp_in_database){
            $data = ['name'=> $otp];
        $user['to'] = $res_for_otp_message[0]->email_address;
        Mail::send('mail', $data, function($messages) use($user){
            $messages->to($user['to']);
            $messages->subject('email verification');
        });
        return view('verify', ['dataforotpmessage'=>$res_for_otp_message]);
        }
    }
    function otp_check(Request $request_for_otp){
        $store_request_for_otp = $request_for_otp->post();
        $request_for_otp->validate([
            'otp' => 'required',
        ]);
        $res_for_get_otp_form_datab_by_username = UserLogin::where('user_name', session('username'))->orWhere('email_address', session('username'))->get();
        if($res_for_get_otp_form_datab_by_username[0]->otp == $store_request_for_otp['otp']){
            $res_for_email_verify_update = UserLogin::where('user_name', session('username'))->orWhere('email_address', session('username'))->update(['email_verify' => 'verified']);
            if($res_for_email_verify_update){
                return redirect('/wallet');
            }
        }
        else{
            session()->flash('wrongotp', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Wrong otp!</strong> Otp you entered is invailed please try again.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
            return redirect('/wallet');
        }
    }
}
