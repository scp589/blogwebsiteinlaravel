<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\allkhabar;

class allkhabarc extends Controller
{
    function data_for_allkhabar(){
        $result_for_badikhabr = allkhabar::where('cat_name', 'like', '%badikhabar%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_desh_ki_khabar = allkhabar::where('cat_name', 'like', '%country%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_rajay = allkhabar::where('cat_name', 'like', '%state%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_district =allkhabar::where('cat_name', 'like', '%district%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_tech = allkhabar::where('cat_name', 'like', '%tech%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_job = allkhabar::where('cat_name', 'like', '%job%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_game = allkhabar::where('cat_name', 'like', '%game%')->orderBy('dt', 'desc')->limit(6)->get();
        $result_for_main_video = allkhabar::where('cat_name', 'like', '%video%')->orderBy('dt', 'desc')->limit(1)->get();
        $result_for_side4_video = allkhabar::where('cat_name', 'like', '%video%')->orderBy('dt', 'desc')->take(4)->skip(1)->get();
        return view('allkhabar', array('dataforbadikhabar'=>$result_for_badikhabr, 'datafordeshkikhabar'=>$result_for_desh_ki_khabar, 'dataforstate'=>$result_for_rajay, 'datafordistrict'=>$result_for_district, 'datafortech'=>$result_for_tech, 'dataforjob'=>$result_for_job, 'dataforgame'=>$result_for_game, 'dataformainvideo'=>$result_for_main_video, 'dataforside4video'=>$result_for_side4_video));
    }

    function singlecat($cat){
        $result_for_single_cat = allkhabar::where('cat_name', 'like', '%'.$cat.'%')->orderBy('dt', 'desc')->limit(6)->get();
        return view('singlecat', array('dataforsinglecat'=>$result_for_single_cat, 'mainheading'=>$cat));
    }

    function singleblog($blog){
        $result_for_single_blog = allkhabar::where('seo_url_heading', ''.$blog.'')->get();
        $result_for_another_news = allkhabar::where('cat_name', 'like', '%another%')->orderBy('dt', 'desc')->limit(12)->get();
        return view('singleblog', array('dataforsingleblog'=>$result_for_single_blog, 'dataforanothernews'=>$result_for_another_news));
        // return view('singleblog', array('dataforsingleblog'=>$result_for_single_blog, 'dataforanothernews'=>$result_for_another_news));
    }

    function search(Request $request_for_search){
        $request_store = $request_for_search->post('search-word');
        $result_for_search = allkhabar::where('main_heading', 'like', '%'.$request_store.'%')->orWhere('min_discription', 'like', '%'.$request_store.'%')->orWhere('full_news', 'like', '%'.$request_store.'%')->orWhere('rajay_name', 'like', '%'.$request_store.'%')->orWhere('rajay_dhani_name', 'like', '%'.$request_store.'%')->orWhere('jeela_name', 'like', '%'.$request_store.'%')->orWhere('place_name', 'like', '%'.$request_store.'%')->orWhere('seo_url_heading', 'like', '%'.$request_store.'%')->orderBy('dt', 'desc')->get();
        return view('search', array('sw'=>$result_for_search));
    }

    function morenews(Request $request_for_more_news){
        // $request_store_for_more_news = $request_for_more_news->post('start_selected');
        $request_store_for_more_news = $request_for_more_news->post();
        // $request_store_for_more_news1 = $request_for_more_news->post('mcat');
        $result_for_more_news = allkhabar::where('cat_name', 'like', '%'.$request_store_for_more_news['mcat'].'%')->orderBy('dt', 'desc')->take(6)->skip($request_store_for_more_news['start_selected'])->get();
        foreach ($result_for_more_news as $row_for_more_news){
            echo '<div class="one-news col-sm-12 col-md-12 col-lg-6">
            <img class="one-news-img" src="../asset/images/'.$row_for_more_news['image_name'].'" alt="">
            <div class="one-news-para-container">
                <p><span class="for-hlc">'.$row_for_more_news['rajay_name'].' </span><span class="slash">/</span> <a href="single_blog/'.$row_for_more_news['seo_url_heading'].'">'.$row_for_more_news['main_heading'].'</a></p>
            </div>
        </div>';
        }
    }

    function mslider(Request $request_mslider){
        // $request_store_mslider = $request_mslider->post('swcat');
        $result_for_mslider = allkhabar::where('cat_name', 'like', '%breakingnews%')->orderBy('dt', 'desc')->get();
        // foreach ($m as $rm) {
        //     echo '<li class="list-item"><a href="/single_blog/'.$rm['seo_url_heading'].'">'.$rm['main_heading'].'</a></li>';
        // }
        return $result_for_mslider;
    }

}
