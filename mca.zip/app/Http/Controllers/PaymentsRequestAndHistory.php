<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Payments;

use App\Models\UserLogin;
use Mail;

class PaymentsRequestAndHistory extends Controller
{
    function payment_request_submit(Request $request_for_pay_req){
        $request_for_pay_req->validate([
            'paytype' => 'required',
            'reqamount' => 'required',
            'reqnum' => 'required',
            'reqcnum' => 'required',
        ]);
        $reqsatore_for_payment = $request_for_pay_req->post();
        $res_for_get_usename_email = UserLogin::where('user_name', session('username'))->orWhere('email_address', session('username'))->get();
      if($res_for_get_usename_email[0]->email_verify == 'verified'){
          if($reqsatore_for_payment['reqamount']<=10){
            if($reqsatore_for_payment['reqnum'] == $reqsatore_for_payment['reqcnum']){
                $res_for_insert_request = Payments::create([
                    'user_name' => $res_for_get_usename_email[0]->user_name,
                    'email_address' => $res_for_get_usename_email[0]->email_address,
                    'amount' => $reqsatore_for_payment['reqamount'],
                    'account_number' => $reqsatore_for_payment['reqnum'],
                    'transiction_type' => $reqsatore_for_payment['paytype'],
                    'transiction_status' => 'pending',
                ]);
                if($res_for_insert_request){
                    $data = ['aboutpayreq'=> 'your request is successfully submitted in your system
                    you will receive you payment in 24 hrs', 'care' => 'please enter mobile number or account number carefully we will not responsible for if you enter wrong mobile number or account number and you cannot receive your payment.'];
                    $user['to'] = $res_for_get_usename_email[0]->email_address;
                    Mail::send('payrequestmail', $data, function($messages) use($user){
                        $messages->to($user['to']);
                        $messages->subject('Payment request');
                    });
                    $data1 = ['aboutpayreqadmin'=> $reqsatore_for_payment, 'name' => $res_for_get_usename_email[0]->user_name, 'mid' => $res_for_get_usename_email[0]->email_address];
                    $user1['to'] = 'st612011@gmail.com';
                    Mail::send('payrequestmailadmin', $data1, function($messages1) use($user1){
                        $messages1->to($user1['to']);
                        $messages1->subject('New payment request');
                    });
                    session()->flash('reqsubmit', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Submit successfully!</strong> Your payment request is submitted successfully you will receive your amount in 24hrs. A email has been sent to your email account about payment request.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>');
                  return redirect('/wallet');
                }
                else{
                    session()->flash('reqnotsubmit', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Request not submit!</strong> Your request is not submit due some error please try after some time.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>');
                  return redirect('/wallet');
                }
            }
            else{
                session()->flash('reqnumnotmatch', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Not match!</strong> Mobile number or account number you entered is not match plaese try again.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>');
              return redirect('/wallet');
            }         
          }
          else{
            session()->flash('maxpayout', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Max payout!</strong> Maximum payout in one time is 10 rupees.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          return redirect('/wallet');
          }
       }
     else{
        session()->flash('emailverifym', '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Email is not verify!</strong> Your email is not verified please verify your eamil to make transactions.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>');
      return redirect('/wallet');
     } 


    }
    function payment_history(){
        $res_for_pay_history = Payments::where('user_name', session('username'))->orWhere('email_address', session('username'))->get();
        return view('paymenthistory', ['dataforpayhistory' => $res_for_pay_history]);
    }
}
