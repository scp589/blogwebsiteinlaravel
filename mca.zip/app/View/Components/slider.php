<?php

namespace App\View\Components;

use Illuminate\View\Component;

use App\Models\allkhabar;

class slider extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        // $result_for_slider = allkhabar::where('cat_name', 'like', '%breakingnews%')->orderBy('dt', 'desc')->get();
        // return view('components.slider', array('dataforslider'=>$result_for_slider));
        return view('components.slider');
    }
}
