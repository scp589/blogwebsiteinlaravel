@extends('main')
@section('title', 'MCAnewsWALA')
@section('mainbody')
<div class="container-fluid mt-5">
    <h3>About us</h3>
    <p class="para-for-about">We are new news firm in India which publish local news and village news and we also
        develop website and android app at low cost. If you want to develop website and android app then visit cuntact
        us page and contact us. We also do advertisements. For advertisement contact on below given email id and
        whatsapp number.</p>
         <!-- crousel start -->
    <iframe src="/team" frameborder="0" scrolling="no" class="slider-iframe"></iframe>
    <!-- crousel end -->
    <h4>website offers</h4>
    <ul class="website-offers">
        <li>5 page static website for Rs 2500 with graphics without hosting plan</li>
        <li>5 page static website for Rs 8000 with one year hosting and domain name</li>
        <li>Fully dynamic website under 15000 rupees with one year hosting and domain name</li>
        <li>e-commerce website in 18000 rupees with one year hosting and domain name</li>
    </ul>
    <p class="para-for-about">
        For any query please contact us on <span><a
                href="mailto: mohit202170@gmail.com">mohit202170@gmail.com</a></span> and whatsapp on. <span><a
                target="_blank" href="https://wa.me/919675204177">96752 04177</a></span>
    </p>
    <p class="para-for-about">
        For more information visit the <span><a href="/contact">contact us</a></span> page
    </p>
</div>
@endsection