@extends('main')
@section('title', 'MCAnewsWALA')
@section('mainbody')
<section class="container-fluid badikhabar-section">
<div class="badikhabar-heading">
         <h3>खोज का परिणाम</h3>
     </div>
     <div class="row badikhabar-new-container">
         <?php
            if(count($sw)>0){
                foreach ($sw as $row_for_sw) {
                    echo '<div class="one-news col-sm-12 col-md-12 col-lg-6">
                        <img class="one-news-img" src="../asset/images/'.$row_for_sw['image_name'].'" alt="image load failed">
                        <div class="one-news-para-container">
                            <p><span class="for-hlc">'.$row_for_sw['rajay_name'].' </span><span class="slash">/</span> <a class="mainheading" href="/single_blog/'.$row_for_sw['seo_url_heading'].'">'.$row_for_sw['main_heading'].'</a></p>
                        </div>
                    </div>';
                }
            }
            else{
                echo '<h2 class="mt-2">आप जो समाचार खोज रहे हैं वह मौजूद नहीं है</h2>';
            }
                ?>
         
     </div>
 </section>
 <!-- search end -->
 @endsection