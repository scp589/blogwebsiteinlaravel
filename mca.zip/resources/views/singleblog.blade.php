@extends('main')
@section('mainbody')
    <!-- single blog start -->
<div class="container pt-2 mt-2">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-8">
                <!-- geeting current url start -->
                @php 
                $getting_current_url = urlencode("https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]")
                @endphp
                <!-- geeting current url end -->
                @foreach($dataforsingleblog as $row_for_single_blog)
                @section('title', $row_for_single_blog['main_heading'])
                <h3 class="news-heading mt-2">{{$row_for_single_blog['main_heading']}}</h3>
                     <h6 class="pt-2 news-min-discription">{{$row_for_single_blog['min_discription']}}</h6>
                     <p class="mt-2">By MCAnewsWALA Digital Desk | Updated Date {{$row_for_single_blog['updated_date']}}</p>
                     <div class="share-links">
                         <span class="share-p">share-on:- </span>
                         <a target="_blank" href="https://wa.me/?text={{$getting_current_url}} | {{$row_for_single_blog['main_heading']}}"><i class="fab fa-whatsapp whatsapp-icon 
                            icon-size-share"></i></a>
                         <a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u={{$getting_current_url}}&quote={{$row_for_single_blog['main_heading']}}"><i class="fab fa-facebook-f icon-size-share"></i></a>
                         <a target="_blank" href=" https://twitter.com/intent/tweet?via={{$getting_current_url}}&text={{$row_for_single_blog['main_heading']}}"><i class="fab fa-twitter twitter-icon icon-size-share"></i></a>
                     </div>
                     <img class="single-main-image" src="../asset/images/{{$row_for_single_blog['image_name']}}" alt="image load failed">
                     <p class="ssingle-snews-spara mt-5"><span class="for-city">{{$row_for_single_blog['place_name']}}:- </span>{!! $row_for_single_blog['full_news'] !!}</p>
                @endforeach
                
            </div>

            <div class="col-sm-12 col-md-12 col-lg-4">
                <h4 class="another-news">अन्य खबरें</h4>
                <div class="div-like-hr"></div>
                <div class="row mt-3">
                    <?php
                    if(count($dataforanothernews)>0){
                        foreach ($dataforanothernews as $row_for_another_news) {
                            echo '<div class="mt-2 col-sm-12 col-md-12 col-lg-12">
                            <a href="/single_blog/'.$row_for_another_news['seo_url_heading'].'" class="another-news-link">
                                <img class="another-image" src="../asset/images/'.$row_for_another_news['image_name'].'"
                                    alt="image-load-failed">
                                <p class="another-min-heading">'.$row_for_another_news['main_heading'].'</p>
                            </a>
                        </div>';
                        }
                    }
                    else{
                        echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
<!-- single blog end -->
<script>
    var session_loggedin = '{{session('loggedin')}}';
   if(session_loggedin==true){
       var token = '{{ csrf_token() }}';
       var increase_amount = 0.1;
       var session_user_name = '{{session('username')}}';
      // update data start
       setTimeout(() => {
        var wallet_btn1 = document.getElementsByClassName('wallet')[0];
        var stonum = Number(wallet_btn1.innerText);
       var finalamount = stonum+increase_amount;
       var oneafdecimal = finalamount.toFixed(1);
       console.log(oneafdecimal);
       console.log('finalamount '+ finalamount)
         $.post('/update_total_amount', {
            sessionname : session_user_name,
            amount : oneafdecimal,
            _token : token
         }, function (data, status){
              console.log(`ststus for update ${status}`);
         }); 
       }, 30000);
       //update data end
       
       console.log(`this is sessionloggedin ${session_loggedin}`);
   }
   else{
       console.log('loogedoout');
       setTimeout(() => {
         myModal.toggle()
       }, 8000);
       var wallet_btn2 = document.getElementsByClassName('wallet');
       Array.from(wallet_btn2).forEach((element)=>{
           element.innerText = 0;
       });
   }
</script>
@endsection