@extends('main')
@section('mainbody')
<div class="container">
    <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">Amount</th>
            <th scope="col">Acoount Number</th>
            <th scope="col">Transaction Type</th>
            <th scope="col">Transaction Date</th>
            <th scope="col">Transaction Status</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($dataforpayhistory as $row_forpay_history)
            @php
             $st ="";  
             if($row_forpay_history['transiction_status'] == 'pending'){
                 $st = 'warning';
             }
             elseif ($row_forpay_history['transiction_status'] == 'payed') {
                 $st = 'success';
             }
             elseif($row_forpay_history['transiction_status'] == 'failed'){
                 $st = 'danger';
             }
             else {
                 $st = "";
             }
            @endphp
          {{-- @elseif(($row_forpay_history['status'] == 'panding') --}}
          <tr class="table-{{$st}}">
            <td>{{$row_forpay_history['amount']}}</td>
            <td>{{$row_forpay_history['account_number']}}</td>
            <td>{{$row_forpay_history['account_number']}}</td>
            <td>{{$row_forpay_history['transiction_type']}}</td>
            <td>{{$row_forpay_history['transiction_date']}}</td>
            <td>{{$row_forpay_history['transiction_status']}}</td>
          </tr>
          @endforeach
        </tbody>
      </table>
</div>
@endsection