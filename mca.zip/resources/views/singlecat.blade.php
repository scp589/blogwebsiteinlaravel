@extends('main')
@section('title', 'MCAnewsWALA')
@section('mainbody')
<!-- slider start -->
<x-slider/>
<!-- slider end -->
 <!-- singlecat start -->
 <section class="container-fluid badikhabar-section">
     <div class="badikhabar-heading">
         <h3><?php
         $dynemaic_heading = "";
         if($mainheading == 'badikhabar'){
             $dynemaic_heading = 'बड़ी ख़बरें';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "country"){
             $dynemaic_heading = 'देश';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "state"){
             $dynemaic_heading = 'राज्य ';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "district"){
             $dynemaic_heading = 'जिला';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "tech"){
             $dynemaic_heading = 'तक्नीकी';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "job"){
             $dynemaic_heading = 'नौकरी';
             echo $dynemaic_heading;
         }
         elseif($mainheading == "game"){
             $dynemaic_heading = 'नौकरी';
             echo $dynemaic_heading;
         }
         ?></h3>
     </div>
     <div class="row badikhabar-new-container" id="cmorenews">
         <input type="hidden" id="incat" value="<?php echo $mainheading;?>">
         <input type="hidden" name="_token" id="token" value="{{ csrf_token() }}">
        <?php
        if(count($dataforsinglecat)>0){
            foreach ($dataforsinglecat as $row_for_single_cat) {
                echo '<div class="one-news col-sm-12 col-md-12 col-lg-6">
                        <img class="one-news-img" src="../asset/images/'.$row_for_single_cat['image_name'].'" alt="image load failed">
                        <div class="one-news-para-container">
                            <p><span class="for-hlc">'.$row_for_single_cat['rajay_name'].' </span><span class="slash">/</span> <a class="mainheading" href="/single_blog/'.$row_for_single_cat['seo_url_heading'].'">'.$row_for_single_cat['main_heading'].'</a></p>
                        </div>
                    </div>';
            }
        }
        else{
            echo '<h2 class="mt-2">आज कोई खबर नहीं है</h2>';
        }
        ?>
     </div>
     <button class="btn aling-text-center mt-2 button-for-more-news" id="morenews">और ख़बरें</button>
 </section>
 <!-- singlecat end -->
 <script>
    var session_loggedin = '{{session('loggedin')}}';
   if(session_loggedin==true){
       var token = '{{ csrf_token() }}';
       var increase_amount = 0.1;
       var session_user_name = '{{session('username')}}';
      // update data start
       setTimeout(() => {
        var wallet_btn1 = document.getElementsByClassName('wallet')[0];
        var stonum = Number(wallet_btn1.innerText);
       var finalamount = stonum+increase_amount;
       var oneafdecimal = finalamount.toFixed(1);
       console.log(oneafdecimal);
       console.log('finalamount '+ finalamount)
         $.post('/update_total_amount', {
            sessionname : session_user_name,
            amount : oneafdecimal,
            _token : token
         }, function (data, status){
              console.log(`ststus for update ${status}`);
         }); 
       }, 30000);
       //update data end
       
       console.log(`this is sessionloggedin ${session_loggedin}`);
   }
   else{
       console.log('loogedoout');
       setTimeout(() => {
         myModal.toggle()
       }, 8000);
       var wallet_btn2 = document.getElementsByClassName('wallet');
       Array.from(wallet_btn2).forEach((element)=>{
           element.innerText = 0;
       });
   }
</script>
@endsection