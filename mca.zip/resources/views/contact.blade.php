@extends('main')
@section('title', 'MCAnewsWALA')
@section('mainbody')
<div class="container mt-5">
    <div class="row">
        <div class="contact-heading col-sm-12 col-md-12 col-lg-12">
            Contact
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-6 col-lg-6 contact-section">
            <h4>For Advertise</h4>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6 contact-section">
            <ul class="contact-details">
                <li>Email:- <span><a href="mailto: mohitpratapsingh@mcanewswala.com">mohitpratapsingh@mcanewswala.com</a></span></li>
                <li>Number:- <span><a href="tel: 96752 04177">96752 04177</a></span></li>
                <li>Contact-Person:- Mohit Pratap Singh</li>
            </ul>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6 contact-section">
            <h4>For Post News</h4>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6 contact-section">
            <ul class="contact-details">
                <li>Email:- <span><a href="mailto: saurabhupadhyay88925@gmail.com">saurabhupadhyay88925@gmail.com</a></span></li>
                <li>Number:- <span><a href="tel: 6396 172 618">6396 172 618</a></span></li>
                <li>Contact-Person:- Saurabh Upadhyay</li>
            </ul>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6 contact-section">
            <h4>For Web And App development</h4>
        </div>
        <div class="col-sm-12 col-md-6 col-lg-6 contact-section">
            <ul class="contact-details">
                <li>Email:- <span><a href="mailto: mohitpratapsingh@mcanewswala.com">mohitpratapsingh@mcanewswala.com</a></span></li>
                <li>Number:- <span><a href="tel: 96752 04177">96752 04177</a></span></li>
                <li>Contact-Persion:- Mohit Pratap Singh</li>
            </ul>
        </div>
    </div>
</div>
@endsection