<div>
     <!-- footer start -->
  <div class="container-fluid">
      <footer class="mt-5 bg-dark">
          <div class="row srow">
              <div class="col-sm-12 col-md-4 col-lg-4 m-auto footer-container">
                  <a href="/about">About us</a>
                  <a href="/contact">Contact us</a>
                  <a href="/termandcondition">Terms & Conditions</a>
              </div>
              <div class="col-sm-12 col-md-4 col-lg-4 m-auto footer-logo">
                      <img src="{{ asset('asset/images/logo5.png')}}" alt="load failed">
              </div>
              <div class="col-sm-12 col-md4 col-lg-4 m-auto">
                  <span class="folow-f">Follow us on:-</span>
                  <a target="_blank" href="https://www.facebook.com/MCA-news-WALA-107496331840938/"><i class="fab fa-facebook-f"></i></a><span class="hr-f"></span>
                  <a target="_blank" href="https://www.youtube.com/channel/UC42NWoRDKK13i6hpNHpajiA"><i class="fab fa-youtube youtube-icon"></i></a><span class="hr-f"></span>
                  <a target="_blank" href=""><i class="fab fa-twitter twitter-icon"></i></a><span class="hr-f"></span>
                  <a target="_blank" href="https://www.instagram.com/mcanewswala/"><i class="fab fa-instagram instagram-icon"></i></a><span class="hr-f"></span>
              </div>
          </div>
          <div class="srow2">
              <p>Copyright © 2022 <span><a target="_blank" href="mcanewswala.com">MCAnewsWALA</a></span></p>
              <p>अगर आप वेबसाइट पर कोई खबर डालना चाहते हैं तो व्हाट्सएप पर भेजें <span><a class="whatsapp-link" href="https://wa.me/916396172618" target="_blank">6396 172 618</a></span></p>
              <p><span>Desinged and Developed by </span><a target="_blank" class="sunny-thakur" href="https://wa.me/91800624053">Sunny Pundhir</a></p>
          </div>
      </footer>
  </div>
  <!-- footer end -->
</div>